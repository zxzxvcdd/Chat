package server.serverDAO;

import java.util.List;
import java.util.Map;

import server.serverDTO.ChatListDTO;
import server.serverDTO.ChatUserDTO;
import server.serverDTO.DepDTO;
import server.serverDTO.EmpDTO;
import server.serverDTO.FileDTO;

public interface ServerDAO {
	
	
	public boolean joinEmployees(EmpDTO emp);
	
	public List<EmpDTO> findAllEmployees();
	
	public EmpDTO findOneEmployees(int empId);
	
	public boolean modifyEmployees(EmpDTO emp);
	
	public boolean deleteEmployees(int empId);
	
	
	
	public boolean createChat(ChatListDTO chat);
	
	public int findChatSeq();
	
	public ChatListDTO findChat(int chatId);
	
	public boolean modifyChatFilePath(int chatId, String filePath);
	
	
	public boolean joinChat(int empId, int chatId);

	public ChatUserDTO findChatUser(Map<String, Object> checkMap);

	public boolean saveFile(FileDTO file);
	
	public FileDTO findFile(FileDTO file);



	public DepDTO findDepartments(int depId);
	
	public boolean deleteDepartments(int depId);
	
	public boolean modifyDepartments(DepDTO dep);
	
}
