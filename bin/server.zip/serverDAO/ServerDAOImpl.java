package server.serverDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import server.serverDBConn.ServerDBConn;
import server.serverDTO.ChatListDTO;
import server.serverDTO.ChatUserDTO;
import server.serverDTO.DepDTO;
import server.serverDTO.EmpDTO;
import server.serverDTO.FileDTO;

public class ServerDAOImpl implements ServerDAO {

	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;

	public ServerDAOImpl() {

		try {
			con = new ServerDBConn().getCon();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public boolean joinEmployees(EmpDTO emp) {

		String sql = "insert into employees(employee_id, pw, name, department_id, tel, admin, job_title)"
				+ " values(?, ?, ?, ?, ? , ?, ?)";

		try {

			pst = con.prepareStatement(sql);

			pst.setInt(1, emp.getEmployeeId());
			pst.setString(2, emp.getPw());
			pst.setString(3, emp.getName());
			pst.setInt(4, emp.getDepartmentId());
			pst.setString(5, emp.getTel());
			pst.setString(6, emp.getAdmin());
			pst.setString(7, emp.getJobTitle());

			int result = pst.executeUpdate();

			if (result >= 1) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			System.out.println("joinEmployees error");
			return false;
		}

	}

	@Override
	public List<EmpDTO> findAllEmployees() {
		// TODO Auto-generated method stub
		String sql = "select e.*, d.department_name" + " from employees e, departments d"
				+ " where e.department_name = d.department_name";

		try {
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();

			List<EmpDTO> empList = new ArrayList<EmpDTO>();

			while (rs.next()) {

				EmpDTO emp = new EmpDTO(rs.getInt("employee_id"), rs.getString("pw"), rs.getString("name"),
						rs.getInt("department_id"), rs.getString("tel"), rs.getString("admin"),
						rs.getString("job_title"));

				emp.setDepartmentName(rs.getString("departmentName"));
				empList.add(emp);

			}

			return empList;

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("findAllEmployees error");

			return null;

		}

	}

	@Override
	public EmpDTO findOneEmployees(int empId) {
		// TODO Auto-generated method stub
		String sql = "select * from employees" + " where employee_id = ?";

		try {
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();

			EmpDTO emp = new EmpDTO(rs.getInt("employee_id"), rs.getString("pw"), rs.getString("name"),
					rs.getInt("department_id"), rs.getString("tel"), rs.getString("admin"), rs.getString("job_title"));

			return emp;

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("findOneEmployees error");

			return null;

		}

	}

	@Override
	public boolean modifyEmployees(EmpDTO emp) {
		// TODO Auto-generated method stub

		String sql = "update employees" + " set (pw, name, deparment_id, tel, job_title)"
				+ " = (?, ?, ?, ?, ?) where employee_id = ?";

		try {
			pst = con.prepareStatement(sql);

			pst.setString(1, emp.getPw());
			pst.setString(2, emp.getName());
			pst.setInt(3, emp.getDepartmentId());
			pst.setString(4, emp.getTel());
			pst.setString(5, emp.getJobTitle());
			pst.setInt(6, emp.getEmployeeId());

			int result = pst.executeUpdate();

			if (result >= 1) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("modifyEmployees error");

			return false;

		}

	}

	@Override
	public boolean deleteEmployees(int empId) {
		// TODO Auto-generated method stub

		String sql = "delete employees" + " where employee_id = ?";

		try {
			pst = con.prepareStatement(sql);

			pst.setInt(1, empId);

			int result = pst.executeUpdate();

			if (result >= 1) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("deleteEmployees error");

			return false;

		}

	}

	@Override
	public boolean createChat(ChatListDTO chat) {
		// TODO Auto-generated method stub

		String sql = "insert into chat_lists (chat_id, chat_name, chat_path)" + " values(chat_seq.NEXTVAL, ?, ?)";

		try {
			pst = con.prepareStatement(sql);

			pst.setString(1, chat.getChatName());
			pst.setString(2, chat.getChatPath());

			int result = pst.executeUpdate();

			if (result >= 1) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("createChat error");

			return false;

		}

	}

	@Override
	public int findChatSeq() {
		// TODO Auto-generated method stub

		String sql = "select chat_list_seq.CURRVAL from dual";

		try {
			pst = con.prepareStatement(sql);

			rs = pst.executeQuery();

			int result = rs.getInt(1);

			return result;

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("findChatSeq error");

			return 0;

		}

	}

	@Override
	public ChatListDTO findChat(int chatId) {
		// TODO Auto-generated method stub

		String sql = "selcet * from chat_lists where chat_id = ?";

		try {
			pst = con.prepareStatement(sql);

			pst.setInt(1, chatId);

			rs = pst.executeQuery();

			ChatListDTO chat = new ChatListDTO(rs.getInt("chat_id"), rs.getString("chat_name"),
					rs.getString("chat_path"));

			return chat;

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("ChatListDTO error");

			return null;

		}

	}

	@Override
	public boolean modifyChatFilePath(int chatId, String filePath) {
		// TODO Auto-generated method stub

		String sql = "update chat_lists set chat_path = ? where chat_id = ?";

		try {
			pst = con.prepareStatement(sql);

			pst.setString(1, filePath);
			pst.setInt(2, chatId);

			int result = pst.executeUpdate();

			if (result >= 1) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("modifyChatFilePath error");

			return false;

		}

	}

	@Override
	public boolean joinChat(int empId, int chatId) {
		// TODO Auto-generated method stub

		String sql = "insert into chat_users (user_id, employee_id, chat_id)" + " values(chat_user_seq.NEXTVAL, ?, ?)";

		try {
			pst = con.prepareStatement(sql);

			pst.setInt(1, empId);
			pst.setInt(2, chatId);

			int result = pst.executeUpdate();

			if (result >= 1) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("joinChat error");

			return false;

		}

	}

	@Override
	public ChatUserDTO findChatUser(Map<String, Object> checkMap) {
		// TODO Auto-generated method stub

		String sql = "select * from chat_users where ? = ?";

		try {
			pst = con.prepareStatement(sql);

			String type = (String) checkMap.get("type");
			int value = (Integer) checkMap.get("value");

			pst.setString(1, type);
			pst.setInt(2, value);

			rs = pst.executeQuery();

			ChatUserDTO user = new ChatUserDTO(rs.getInt("user_i"), rs.getInt("employee_id"), rs.getInt("chat_id"));

			return user;

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("findChatUser error");

			return null;

		}

	}

	@Override
	public boolean saveFile(FileDTO file) {
		// TODO Auto-generated method stub

		String sql = "insert into files(file_id, file_path, employee_id, chat_id)"
				+ " values(file_seq_NEXTVAL, ?, ?, ?)";

		try {
			pst = con.prepareStatement(sql);

			pst.setString(1, file.getFilePath());
			pst.setInt(2, file.getEmployeeId());
			pst.setInt(3, file.getChatId());

			int result = pst.executeUpdate();

			if (result >= 1) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("saveFile error");

			return false;

		}

	}

	@Override
	public FileDTO findFile(FileDTO file) {
		String sql = "select * from files where file_id = ?";

		try {
			pst = con.prepareStatement(sql);

			pst.setInt(1, file.getFileId());

			rs = pst.executeQuery();

			file.setEmployeeId(rs.getInt("employee_id"));
			file.setChatId(rs.getInt("chat_id"));
			file.setFileName(rs.getString("file_name"));
			file.setFilePath(rs.getString("file_path"));

			return file;

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("findFile error");

			return null;

		}

	};

	@Override
	public DepDTO findDepartments(int depId) {
		// TODO Auto-generated method stub

		String sql = "select * from departments where department_id = ?";

		try {
			pst = con.prepareStatement(sql);

			pst.setInt(1, depId);

			rs = pst.executeQuery();

			DepDTO dep = new DepDTO();

			dep.setDepartmentId(depId);
			dep.setDepartmentName(rs.getString("department_name"));

			return dep;

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("findDepartments error");

			return null;

		}

	}

	@Override
	public boolean deleteDepartments(int depId) {
		// TODO Auto-generated method stub

		String sql = "delete departments where department_id = ?";

		try {
			pst = con.prepareStatement(sql);

			pst.setInt(1, depId);

			int result = pst.executeUpdate();

			if (result >= 1) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("deleteDepartments error");

			return false;

		}

	}

	@Override
	public boolean modifyDepartments(DepDTO dep) {
		// TODO Auto-generated method stub

		String sql = "update departments set (department_id, department_name) = (?, ?)";

		try {
			pst = con.prepareStatement(sql);

			pst.setInt(1, dep.getDepartmentId());
			pst.setString(2, dep.getDepartmentName());

			int result = pst.executeUpdate();

			if (result >= 1) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();

			System.out.println("modifyDepartments error");

			return false;

		}

	}

}
