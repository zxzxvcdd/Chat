package server.serverService;

import server.serverDAO.ServerDAO;
import server.serverDAO.ServerDAOImpl;

public class ChatService {

	
	ServerDAO dao = new ServerDAOImpl();
	
	
	
}
